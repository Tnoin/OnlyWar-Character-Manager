import random


def roll_die(die):
    return random.randint(1, die)
